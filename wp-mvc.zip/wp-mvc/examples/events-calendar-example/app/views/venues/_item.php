<div>
    <?php echo $this->html->venue_link($object); ?>
</div>