<?php

class SpeakersController extends MvcPublicController {
    
}

?>