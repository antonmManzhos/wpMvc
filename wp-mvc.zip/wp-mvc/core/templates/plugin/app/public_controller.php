<?php echo "<?php\n"; ?>

class <?php echo $name_pluralized ?>Controller extends MvcPublicController {
    
}

<?php echo '?>'; ?>