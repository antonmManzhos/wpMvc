<?php get_header(); ?>

<?php $this->render_main_view(); ?>

<?php get_footer(); ?>